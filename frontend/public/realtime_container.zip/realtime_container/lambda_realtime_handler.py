import tempfile
import os, json, io, time
import boto3
import numpy as np
from datetime import datetime, timezone, timedelta
from botocore.config import Config

BUCKET = os.environ["BUCKET"]
EVENT_TABLE = os.environ.get("EVENT_TABLE", "UserEventBuffer")
GAP_MINUTES = int(os.environ.get("GAP_MINUTES", "30"))
ALPHA = float(os.environ.get("ALPHA", "5.0"))  # ★ risk 스케일링 파라미터

# S3 Paths
DOC2VEC_ROOT = "models/doc2vec"
OCSVM_ROOT   = "models/ocsvm"
DBSCAN_ROOT  = "models/dbscan"

s3 = boto3.client("s3", config=Config(retries={"max_attempts": 5, "mode": "standard"}))
dynamodb = boto3.resource("dynamodb")
TABLE = dynamodb.Table(EVENT_TABLE)

# Caches
_doc2vec = None
_ocsvm_model = None
_ocsvm_scaler = None
_dbscan  = {"components": None, "core_labels": None, "eps": None, "metric": "cosine"}

events = boto3.client("events")

def emit_anomaly(detail: dict):
    events.put_events(Entries=[{
        "Source": "ct.realtime",
        "DetailType": "Security.AnomalyDetected",
        "Detail": json.dumps(detail),
    }])

def _sigmoid(z):  # ★ 공통 시그모이드
    # overflow 방지용 clip
    z = max(min(z, 60.0), -60.0)
    return 1.0 / (1.0 + np.exp(-z))

def _latest_prefix(root):
    # Find latest yyyy/mm/dd under given root
    def _list(prefix):
        resp = s3.list_objects_v2(Bucket=BUCKET, Prefix=prefix, Delimiter='/')
        return resp.get("CommonPrefixes", [])
    years = [x["Prefix"] for x in _list(f"{root}/")]
    years.sort(reverse=True)
    for yp in years:
        months = [x["Prefix"] for x in _list(yp)]
        months.sort(reverse=True)
        for mp in months:
            days = [x["Prefix"] for x in _list(mp)]
            days.sort(reverse=True)
            if days:
                return days[0]
    return None

def _pick_today_or_latest(root):
    today = datetime.now(timezone.utc).astimezone().strftime("%Y/%m/%d")
    tprefix = f"{root}/{today}/"
    r = s3.list_objects_v2(Bucket=BUCKET, Prefix=tprefix, MaxKeys=1)
    if r.get("KeyCount", 0) > 0:
        return tprefix
    return _latest_prefix(root)

def _load_doc2vec():
    global _doc2vec
    if _doc2vec is not None:
        return _doc2vec
    import gensim
    pref = _pick_today_or_latest(DOC2VEC_ROOT)
    if not pref:
        raise RuntimeError("No doc2vec model found")
    key = pref + "model.bin"
    with tempfile.NamedTemporaryFile() as tf:
        s3.download_file(BUCKET, key, tf.name)
        _doc2vec = gensim.models.Doc2Vec.load(tf.name)
    return _doc2vec

def _load_ocsvm():
    """Load OCSVM payload saved as joblib with dict: {'scaler':..., 'model':...}"""
    global _ocsvm_model, _ocsvm_scaler
    if _ocsvm_model is not None:
        return _ocsvm_model, _ocsvm_scaler
    import joblib
    pref = _pick_today_or_latest(OCSVM_ROOT)
    if not pref:
        raise RuntimeError("No OCSVM model found")
    key = pref + "model.joblib"
    with tempfile.NamedTemporaryFile() as tf:
        s3.download_file(BUCKET, key, tf.name)
        payload = joblib.load(tf.name)
    if isinstance(payload, dict):
        _ocsvm_scaler = payload.get("scaler", None)
        _ocsvm_model  = payload.get("model", payload.get("ocsvm"))
    else:
        # backward-compat: model only
        _ocsvm_model = payload
        _ocsvm_scaler = None
    if _ocsvm_model is None:
        raise RuntimeError("OCSVM model missing in joblib payload")
    return _ocsvm_model, _ocsvm_scaler

def _load_dbscan():
    global _dbscan
    if _dbscan["components"] is not None:
        return _dbscan
    pref = _pick_today_or_latest(DBSCAN_ROOT)
    if not pref:
        return _dbscan
    with tempfile.TemporaryDirectory() as td:
        for name in ["components.npy","core_labels.npy","params.json"]:
            s3.download_file(BUCKET, pref + name, os.path.join(td, name))
        comp = np.load(os.path.join(td, "components.npy"))
        labs = np.load(os.path.join(td, "core_labels.npy"))
        with open(os.path.join(td, "params.json")) as f:
            params = json.load(f)
    _dbscan = {"components": comp, "core_labels": labs,
               "eps": float(params.get("eps", 0.5)), "metric": params.get("metric","cosine")}
    return _dbscan

def _l2norm(a):
    n = np.linalg.norm(a, axis=1, keepdims=True) + 1e-12
    return a / n

def infer_doc2vec(seq):
    m = _load_doc2vec()
    # gensim 4.x: epochs 인자 사용
    return m.infer_vector(seq, alpha=0.025, min_alpha=0.0001, epochs=100)

def ocsvm_score(vec):
    model, scaler = _load_ocsvm()
    import numpy as np
    x = np.asarray(vec, dtype=np.float32).reshape(1, -1)
    if scaler is not None:
        x = scaler.transform(x)
    if hasattr(model, "decision_function"):
        s = float(model.decision_function(x)[0])
    elif hasattr(model, "score_samples"):
        s = float(model.score_samples(x)[0])
    else:
        raise RuntimeError("OCSVM object has neither decision_function nor score_samples")
    return s, (s > 0.0)

def dbscan_predict(vec):
    """
    Returns:
        label (int)
        is_noise (bool)
        dist_min (float)  ★ 최근접 core point 거리
        eps (float)       ★ DBSCAN eps
    """
    art = _load_dbscan()
    if art["components"] is None:
        # no DBSCAN artifacts available: treat as unknown/noise
        return -1, True, float("inf"), float(art["eps"] or 0.0)
    comp = art["components"]
    labels = art["core_labels"]
    eps = art["eps"]
    v = np.asarray(vec, dtype=np.float32).reshape(1, -1)
    if art["metric"] == "cosine":
        v = _l2norm(v)
        compn = _l2norm(comp)
        sim = (v @ compn.T).reshape(-1)
        dist = 1.0 - sim
    else:
        dist = np.linalg.norm(comp - v, axis=1)
    idx = int(np.argmin(dist))
    dmin = float(dist[idx])
    return ((int(labels[idx]), False, dmin, float(eps)) if dmin <= eps else (-1, True, dmin, float(eps)))

def get_last_events(user_id, ts_iso):
    # 주의: boto3.dynamodb.conditions.Key 를 쓰는 것이 정석이나,
    # 현재 환경에서 문자열 표현이 동작 중이면 그대로 둡니다.
    resp = TABLE.query(
        KeyConditionExpression="userId = :u AND #ts <= :t",
        ExpressionAttributeValues={":u": user_id, ":t": ts_iso},
        ExpressionAttributeNames={"#ts": "timestamp"},
        ScanIndexForward=False,
        Limit=31
    )
    items = resp.get("Items", [])
    items = list(reversed(items))[-31:]
    return items

def is_initial_session(items):
    """
    새 규칙:
    - (20,21), (25,26), (30,31) 중 하나라도 30분 이상 차이나는 페어가 있으면
      그 페어의 '오래된 쪽'(21/26/31)과 가장 최근(1) 사이가 30분 이하일 때만 True.
    - 해당 페어가 없으면 False.
    - 31개 미만이면 기존 간단 로직(마지막 두 이벤트 간격 기준)으로 폴백.
    """
    n = len(items)
    if n < 2:
        return False  # 너무 적으면 초기 세션으로 간주(기존 동작 유지)

    def dt(s):
        return datetime.fromisoformat(s.replace("Z", "+00:00"))

    # items는 오래된→최근 오름차순으로 정렬되어 있다고 가정
    # 위치 pos: 1=가장 최근, n=가장 오래된
    def idx(pos):
        return n - pos

    def minutes_between(pos_newer, pos_older):
        """pos_newer < pos_older 전제(최근 쪽 먼저). 양수(분) 반환."""
        t_new = dt(items[idx(pos_newer)]["timestamp"])
        t_old = dt(items[idx(pos_older)]["timestamp"])
        return (t_new - t_old).total_seconds() / 60.0

    # 31개가 충분히 있을 때 검사할 페어 목록
    pairs = []
    if n >= 21: pairs.append((20, 21))
    if n >= 26: pairs.append((25, 26))
    if n >= 31: pairs.append((30, 31))

    found_boundary = False
    for newer_pos, older_pos in pairs:
        gap_pair = minutes_between(newer_pos, older_pos)  # 예: (20,21)
        if gap_pair >= GAP_MINUTES:
            found_boundary = True
            # 오래된 쪽(21/26/31)과 가장 최근(1) 사이가 GAP 이하면 True
            if minutes_between(1, older_pos) <= GAP_MINUTES:
                return True
            # 이 페어는 조건 미충족 → 다른 페어도 확인(어느 하나라도 만족하면 True)
            # 계속 루프 진행

    if found_boundary:
        # 하나라도 경계는 있었지만, 1과 오래된 쪽 간격이 모두 GAP 초과 → False
        return False

    # 경계 자체가 없었음 → 31개 미만이면 폴백, 아니면 False
    if n < 31:
        # 폴백: 마지막 두 이벤트 간격으로 판단
        last_gap = (dt(items[-1]["timestamp"]) - dt(items[-2]["timestamp"])).total_seconds() / 60.0
        return last_gap >= GAP_MINUTES

    return False


def lambda_handler(event, context):
    # Parse input (DDB Streams default) or direct JSON
    try:
        rec = event["Records"][0]["dynamodb"]["NewImage"]
        user_id = rec["userId"]["S"]
        ts_iso  = rec["timestamp"]["S"]
        ev_name = rec["eventName"]["S"]
    except Exception:
        user_id = event.get("userId")
        ts_iso  = event.get("timestamp")
        ev_name = event.get("eventName")
    if not (user_id and ts_iso and ev_name):
        raise RuntimeError("Missing userId/timestamp/eventName")

    items = get_last_events(user_id, ts_iso)
    if not items or items[-1].get("timestamp") != ts_iso:
        items.append({"userId": user_id, "timestamp": ts_iso, "eventName": ev_name})
        items = items[-20:]

    seq = [it["eventName"] for it in items][-20:]
    if len(seq) < 20:
        return {"ok": False, "reason": "insufficient_history", "len": len(seq)}

    vec = infer_doc2vec(seq)
    init = is_initial_session(items)

    if init:
        score, inlier = ocsvm_score(vec)
        # ★ risk = 100 * σ(α * (-f(x)))
        risk = 100.0 * _sigmoid(ALPHA * (-score))
        result = {
            "engine": "ocsvm",
            "score": score,
            "is_anomaly": (not inlier),
            "risk": float(risk)  # 0 ~ 100
        }
    else:
        label, is_noise, dmin, eps = dbscan_predict(vec)
        # ★ r = d_core(x)/eps, risk = 100 * σ(α * (r - 1))
        r = (dmin / eps) if eps > 0 else float("inf")
        risk = 100.0 * _sigmoid(ALPHA * (r - 1.0))
        result = {
            "engine": "dbscan",
            "cluster": (label if label is not None else -1),
            "is_noise": bool(is_noise),
            "nearest_dist": float(dmin),
            "eps": float(eps),
            "r": float(r),
            "risk": float(risk)  # 0 ~ 100
        }

    # 이상 신호 → EventBridge로 통지 (Remediation Lambda가 TEST 모드로 받도록 구성됨)
    if result["engine"] == "dbscan" and result.get("is_noise"):
        emit_anomaly({
            "principalType": "IAMUser",
            "username": user_id,
            "principalArn": event.get("principalArn", ""),
            "reason": "dbscan_noise",
            "severity": "high"
        })
    if result["engine"] == "ocsvm" and result.get("is_anomaly"):
        emit_anomaly({
            "principalType": "IAMUser",
            "username": user_id,
            "reason": "ocsvm_anomaly",
            "severity": "high"
        })

    out = {
        "ok": True,
        "userId": user_id,
        "timestamp": ts_iso,
        "eventName": ev_name,
        "initial_session": init,
        "embedding_dim": int(len(vec)),
        "result": result
    }
    key = f"results/realtime/{datetime.now(timezone.utc).strftime('%Y/%m/%d')}/{user_id}-{int(time.time())}.json"
    s3.put_object(Bucket=BUCKET, Key=key, Body=json.dumps(out).encode("utf-8"))
    return out
