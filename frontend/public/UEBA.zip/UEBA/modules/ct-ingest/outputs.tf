output "user_event_table_arn" {
  value = aws_dynamodb_table.user_event_buffer.arn
}

output "user_event_table_name" {
  value = aws_dynamodb_table.user_event_buffer.name
}

output "trail_bucket_name" {
  value = aws_s3_bucket.trail_bucket.bucket
}

output "event_collector_lambda_name" {
  value = aws_lambda_function.event_collector.function_name
}

output "user_event_stream_arn" {
  value = aws_dynamodb_table.user_event_buffer.stream_arn
}
