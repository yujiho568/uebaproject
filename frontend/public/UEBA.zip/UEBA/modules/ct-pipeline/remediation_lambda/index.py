import os
import json
import logging
from datetime import datetime, timedelta, timezone

import boto3

log = logging.getLogger()
log.setLevel(logging.INFO)

iam = boto3.client("iam")

POLICY_NAME = os.environ.get("QUARANTINE_POLICY_NAME", "QuarantineDenyAll")
DEFAULT_MINUTES = int(os.environ.get("QUARANTINE_MINUTES", "15"))  # 기본 15분


def _build_timeboxed_deny(minutes: int) -> dict:
    """
    현재(UTC) 시각 기준 N분 동안만 유효한 Deny 정책을 생성합니다.
    시간이 지나면 정책은 붙어 있어도 효과가 사라집니다.
    """
    until = datetime.now(timezone.utc) + timedelta(minutes=minutes)
    return {
        "Version": "2012-10-17",
        "Statement": [{
            "Sid": "TimeboxedQuarantine",
            "Effect": "Deny",
            "Action": "*",
            "Resource": "*",
            "Condition": {
                "DateLessThan": {
                    "aws:CurrentTime": until.strftime("%Y-%m-%dT%H:%M:%SZ")
                }
            }
        }]
    }


def _quarantine_iam_user(username: str, minutes: int):
    """
    대상 IAM User에 타임박스 Deny 인라인 정책을 부착합니다.
    동일 PolicyName으로 put_user_policy를 호출하면 갱신/덮어쓰기 됩니다.
    """
    policy_doc = _build_timeboxed_deny(minutes)
    # iam.put_user_policy(
    #     UserName=username,
    #     PolicyName=POLICY_NAME,
    #     PolicyDocument=json.dumps(policy_doc),
    # )
    return {
        "action": "iam_user_quarantined_timeboxed",
        "username": username,
        "minutes": minutes,
    }


def handler(event, context):
    """
    기대 입력 예시:
    {
      "detail": {
        "principalType": "IAMUser",
        "username": "alice",         # or "userName"
        "minutes": 10,               # (선택) 없으면 기본값 사용
        "reason": "anomalous_activity"
      }
    }
    """
    try:
        log.info("event=%s", json.dumps(event)[:2000])
    except Exception:
        pass

    d = (event or {}).get("detail", {}) or {}
    ptype = d.get("principalType")  # 기대값: "IAMUser"
    reason = d.get("reason", "unknown")

    try:
        if ptype != "IAMUser":
            raise ValueError(f"unsupported principalType for this lambda (only IAMUser allowed): {ptype}")

        username = d.get("username") or d.get("userName")
        if not username:
            raise ValueError("username missing for IAMUser")

        minutes = DEFAULT_MINUTES
        if "minutes" in d:
            try:
                minutes = int(d.get("minutes"))
            except Exception:
                # 잘못된 값이면 기본값 사용
                minutes = DEFAULT_MINUTES

        res = _quarantine_iam_user(username, minutes)

        out = {"ok": True, "reason": reason, **res}
        try:
            log.info("remediation=%s", json.dumps(out))
        except Exception:
            pass
        return out

    except Exception as e:
        try:
            log.exception("remediation failed")
        except Exception:
            pass
        return {"ok": False, "error": str(e), "detail": d}
