import os
import json
import boto3

s3 = boto3.client('s3')
ddb = boto3.client('dynamodb')

def lambda_handler(event, context):
    bucket = os.environ['BUCKET']
    results_table = os.environ['RESULTS_TABLE']

    # date_path comes from Step Functions context (Count lambda result)
    date_path = None
    try:
        date_path = event.get('countResult', {}).get('date_path')
    except Exception:
        pass

    if not date_path:
        # fallback: optional direct event field
        date_path = event.get('date_path')

    if not date_path:
        raise RuntimeError("date_path not found in event")

    key = f"results/dbscan/{date_path}/stats.json"
    obj = s3.get_object(Bucket=bucket, Key=key)
    stats = json.loads(obj['Body'].read().decode('utf-8'))

    ddb.put_item(
        TableName=results_table,
        Item={
            'pk': {'S': f'DATE#{date_path}'},
            'sk': {'S': 'SUMMARY'},
            'payload': {'S': json.dumps(stats)}
        }
    )

    return {"ok": True, "date_path": date_path}
