import os, glob, json, gzip
import pandas as pd
import pyarrow.parquet as pq
from boto3.dynamodb.types import TypeDeserializer

def _read_parquet_file(path):
    try:
        return pq.read_table(path).to_pandas()
    except Exception:
        return pd.read_parquet(path)

def load_parquet_folder_local(root_dir):
    files = glob.glob(os.path.join(root_dir, "**", "*.parquet"), recursive=True)
    dfs = []
    for fp in files:
        try:
            dfs.append(_read_parquet_file(fp))
        except Exception:
            pass
    return pd.concat(dfs, ignore_index=True) if dfs else pd.DataFrame()

def _iter_json_lines(path):
    opener = gzip.open if path.endswith(".gz") else open
    with opener(path, "rt", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            yield json.loads(line)

def _dynjson_to_python(obj):
    deser = TypeDeserializer()
    if "Item" in obj and isinstance(obj["Item"], dict):
        return {k: deser.deserialize(v) for k, v in obj["Item"].items()}
    if isinstance(obj, dict) and all(isinstance(v, dict) and len(v)==1 for v in obj.values()):
        return {k: deser.deserialize(v) for k, v in obj.items()}
    return obj

def load_dynamodb_json_folder(root_dir):
    files = glob.glob(os.path.join(root_dir, "**", "*.json"), recursive=True)
    files += glob.glob(os.path.join(root_dir, "**", "*.json.gz"), recursive=True)
    rows = []
    for fp in files:
        try:
            for obj in _iter_json_lines(fp):
                rows.append(_dynjson_to_python(obj))
        except Exception:
            pass
    return pd.DataFrame(rows) if rows else pd.DataFrame()

def save_json_local(path, obj):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        import json
        json.dump(obj, f, ensure_ascii=False, indent=2)
