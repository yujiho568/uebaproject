import os, sys, logging
import numpy as np
import pandas as pd

from utils import ensure_dirs
from io_util import load_parquet_folder_local, load_dynamodb_json_folder, save_json_local
from preprocess import breakpoints_by_gap, sliding_windows, sequences_by_segments
from d2v import train_doc2vec, infer_batch
from ocsvm import train_ocsvm
from dbscan_auto import run_dbscan_cosine

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s", stream=sys.stdout)
log = logging.getLogger("processing")

def main():
    input_dir   = os.environ.get("SM_INPUT_DIR", "/opt/ml/processing/input")
    models_dir  = os.environ.get("SM_MODELS_DIR", "/opt/ml/processing/models")
    results_dir = os.environ.get("SM_RESULTS_DIR", "/opt/ml/processing/results")

    DATE        = os.environ.get("DATE")
    GAP         = int(os.environ.get("GAP_MINUTES", "30"))
    WIN         = int(os.environ.get("WIN_DOC2VEC", "20"))
    STRIDE1     = int(os.environ.get("STRIDE_DOC2VEC", "1"))
    VEC         = int(os.environ.get("VEC_SIZE", "64"))
    WIN_SEG     = int(os.environ.get("WIN_SEG", "20"))
    STRIDE5     = int(os.environ.get("STRIDE_SEG", "5"))
    MAX_PER     = int(os.environ.get("MAX_SEQ_PER_SEG", "5"))
    OCSVM_NU    = float(os.environ.get("OCSVM_NU", "0.05"))
    DB_MIN      = int(os.environ.get("DBSCAN_MIN_SAMPLES", "10"))
    DB_K        = int(os.environ.get("DBSCAN_K", "10"))
    DB_P        = int(os.environ.get("DBSCAN_EPS_PCTL", "90"))

    ensure_dirs(models_dir, results_dir)

    raw_dir = input_dir
    df = load_dynamodb_json_folder(raw_dir)
    if df.empty:
        df = load_parquet_folder_local(raw_dir)
    if df.empty:
        raise RuntimeError("No input data found (DynamoDB JSON or Parquet)")

    def find_col(candidates):
        cols = list(df.columns)
        for cand in candidates:
            for name in cols:
                if cand in name.lower():
                    return name
        return None

    time_col = find_col(["eventtime","event_time"])
    name_col = find_col(["eventname","event_name"])

    if time_col is None or name_col is None:
        raise RuntimeError(f"Cannot find eventTime/eventName columns in df: {list(df.columns)}")

    df = df[[time_col, name_col]].rename(columns={time_col:"eventTime", name_col:"eventName"})
    df["eventTime"] = pd.to_datetime(df["eventTime"], errors="coerce")
    df = df.dropna(subset=["eventTime","eventName"]).sort_values("eventTime")
    tokens_all = df["eventName"].astype(str).tolist()

    corpus_train = sliding_windows(tokens_all, win=WIN, stride=STRIDE1)
    d2v = train_doc2vec(corpus_train, vec_size=VEC, window=WIN, epochs=30)
    d2v.save(os.path.join(models_dir, "doc2vec_model.bin"))

    ts = df["eventTime"].values
    bps = breakpoints_by_gap(ts, gap_minutes=GAP)
    seqs_seg = sequences_by_segments(tokens_all, bps, win=WIN_SEG, stride=STRIDE5, max_per_seg=MAX_PER)

    X_oc = np.array(infer_batch(d2v, seqs_seg, epochs=30)) if seqs_seg else np.empty((0, VEC))
    from sklearn.preprocessing import StandardScaler
    if len(X_oc) > 0:
        scaler = StandardScaler(with_mean=True, with_std=True).fit(X_oc)
        Xs = scaler.transform(X_oc)
        oc = train_ocsvm(Xs, nu=OCSVM_NU)
        import joblib
        joblib.dump({"scaler":scaler,"model":oc}, os.path.join(models_dir,"ocsvm_model.joblib"))

    X_db = np.array(infer_batch(d2v, corpus_train, epochs=30))
    eps, labels = run_dbscan_cosine(X_db, min_samples=DB_MIN, k=DB_K, pctl=DB_P)

    stats = {
        "date": DATE or "",
        "count_events": int(len(df)),
        "count_seqs_train": int(len(corpus_train)),
        "count_seqs_seg": int(len(seqs_seg)),
        "dbscan_eps": float(eps),
        "dbscan_clusters": int(len(set([l for l in labels if l != -1]))),
        "dbscan_noise_ratio": float(sum([1 for l in labels if l==-1])/len(labels)) if len(labels)>0 else 0.0
    }
    save_json_local(os.path.join(results_dir, "stats.json"), stats)
    with open(os.path.join(results_dir,"labels.csv"),"w",encoding="utf-8") as f:
        f.write("idx,label\n")
        for i,l in enumerate(labels):
            f.write(f"{i},{l}\n")

    log.info("Processing done.")

if __name__=="__main__":
    sys.exit(main())
