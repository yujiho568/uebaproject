# Processing Container (Doc2Vec + OCSVM + DBSCAN)
SageMaker Processing entrypoint. Expects input data (DynamoDB JSON export or Parquet) under
`/opt/ml/processing/input` and writes outputs to:
- `/opt/ml/processing/models/doc2vec/YYYY/MM/DD/model.bin`
- `/opt/ml/processing/models/ocsvm/YYYY/MM/DD/model.joblib`
- `/opt/ml/processing/results/dbscan/YYYY/MM/DD/{stats.json, labels.csv}`
Environment Variables: DATE, GAP_MINUTES, WIN_DOC2VEC, STRIDE_DOC2VEC, VEC_SIZE, WIN_SEG, STRIDE_SEG, MAX_SEQ_PER_SEG, OCSVM_NU, DBSCAN_MIN_SAMPLES, DBSCAN_EPS_PCTL, DBSCAN_K, EVENT_TIME_FIELD, EVENT_NAME_FIELD
