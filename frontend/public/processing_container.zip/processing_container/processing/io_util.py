import os, glob, json, gzip
import pandas as pd
import pyarrow.parquet as pq
from boto3.dynamodb.types import TypeDeserializer

def _read_parquet_file(path):
    try:
        return pq.read_table(path).to_pandas()
    except Exception:
        return pd.read_parquet(path)

def load_parquet_folder_local(root_dir):
    files = glob.glob(os.path.join(root_dir, "**", "*.parquet"), recursive=True)
    dfs = []
    for fp in files:
        try:
            dfs.append(_read_parquet_file(fp))
        except Exception:
            pass
    return pd.concat(dfs, ignore_index=True) if dfs else pd.DataFrame()

def _iter_json_lines_or_whole(path):
    # 1) line-delimited JSON 우선 시도
    opener = gzip.open if path.endswith(".gz") else open
    any_line = False
    try:
        with opener(path, "rt", encoding="utf-8") as f:
            for line in f:
                s = line.strip()
                if not s:
                    continue
                any_line = True
                yield json.loads(s)
        if any_line:
            return
    except Exception:
        pass

    # 2) 통째로 파싱 (배열/단일 객체)
    try:
        with opener(path, "rt", encoding="utf-8") as f:
            data = json.load(f)
        if isinstance(data, list):
            for obj in data:
                yield obj
        else:
            yield data
    except Exception:
        # 마지막 폴백 실패: 무시
        return

def _dynjson_to_python(obj):
    deser = TypeDeserializer()
    # {"Item": {... DynamoDB JSON ...}} -> 평탄화
    if isinstance(obj, dict) and "Item" in obj and isinstance(obj["Item"], dict):
        return {k: deser.deserialize(v) for k, v in obj["Item"].items()}
    # {"k":{"S":"v"}, ...} 형태
    if isinstance(obj, dict) and obj and all(isinstance(v, dict) and len(v)==1 for v in obj.values()):
        try:
            return {k: deser.deserialize(v) for k, v in obj.items()}
        except Exception:
            return None
    return None  # manifest 등은 None

def load_dynamodb_json_folder(root_dir):
    """
    일반 경로:
      <prefix>/AWSDynamoDB/<export-id>/{data/*.json(.gz), manifest-*}
    1) data/만 우선 스캔, 2) 없으면 전체에서 fallback 스캔
    """
    patterns_data = [
        os.path.join(root_dir, "**", "AWSDynamoDB", "**", "data", "*.json"),
        os.path.join(root_dir, "**", "AWSDynamoDB", "**", "data", "*.json.gz"),
    ]
    files = []
    for pat in patterns_data:
        files.extend(glob.glob(pat, recursive=True))

    if not files:
        # fallback: 혹시 프리픽스 구조가 다르거나 data/ 없이 파일이 올 수 있으니 전체 스캔
        patterns_all = [
            os.path.join(root_dir, "**", "*.json"),
            os.path.join(root_dir, "**", "*.json.gz"),
        ]
        for pat in patterns_all:
            files.extend(glob.glob(pat, recursive=True))

    rows = []
    for fp in files:
        try:
            for obj in _iter_json_lines_or_whole(fp):
                rec = _dynjson_to_python(obj)
                if rec is not None:
                    rows.append(rec)
        except Exception:
            # 파일 하나 실패는 건너뛰기
            pass

    return pd.DataFrame(rows) if rows else pd.DataFrame()
