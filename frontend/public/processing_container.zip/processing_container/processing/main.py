import os, sys, logging
import numpy as np
import pandas as pd
import subprocess
subprocess.run(["bash","-lc","echo '--- input listing ---'; ls -lR /opt/ml/processing/input | sed -n '1,400p'"], check=False)
from datetime import datetime
from utils import ensure_dirs, save_json
from io_util import load_parquet_folder_local, load_dynamodb_json_folder
from preprocess import breakpoints_by_gap, sliding_windows, sequences_by_segments
from d2v import train_doc2vec, infer_batch
from ocsvm import train_ocsvm
from dbscan_auto import run_dbscan_cosine
logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s", stream=sys.stdout)
log = logging.getLogger("processing")
def _pick_col(df, wanted, fallbacks_lower):
    if wanted and wanted in df.columns:
        return wanted
    if wanted and "." in wanted:
        cur = df
        try:
            for part in wanted.split("."):
                cur = cur.apply(lambda r: r.get(part) if isinstance(r, dict) else None)
            newcol = "__tmp_col__"
            df[newcol] = cur
            return newcol
        except Exception:
            pass
    cols = list(df.columns)
    for cand in fallbacks_lower:
        for c in cols:
            if cand in c.lower():
                return c
    return None
def main():
    input_dir   = os.environ.get("SM_INPUT_DIR", "/opt/ml/processing/input")
    models_dir  = os.environ.get("SM_MODELS_DIR", "/opt/ml/processing/models")
    results_dir = os.environ.get("SM_RESULTS_DIR", "/opt/ml/processing/results")
    DATE        = os.environ.get("DATE")
    GAP         = int(os.environ.get("GAP_MINUTES", "30"))
    WIN         = int(os.environ.get("WIN_DOC2VEC", "20"))
    STRIDE1     = int(os.environ.get("STRIDE_DOC2VEC", "1"))
    VEC         = int(os.environ.get("VEC_SIZE", "64"))
    WIN_SEG     = int(os.environ.get("WIN_SEG", "20"))
    STRIDE5     = int(os.environ.get("STRIDE_SEG", "5"))
    MAX_PER     = int(os.environ.get("MAX_SEQ_PER_SEG", "5"))
    OCSVM_NU    = float(os.environ.get("OCSVM_NU", "0.05"))
    DB_MIN      = int(os.environ.get("DBSCAN_MIN_SAMPLES", "10"))
    DB_K        = int(os.environ.get("DBSCAN_K", "10"))
    DB_P        = int(os.environ.get("DBSCAN_EPS_PCTL", "90"))
    EVT_TIME    = os.environ.get("EVENT_TIME_FIELD")
    EVT_NAME    = os.environ.get("EVENT_NAME_FIELD")
    date_path = DATE or datetime.utcnow().strftime("%Y/%m/%d")
    out_models_d2v = os.path.join(models_dir, "doc2vec", date_path)
    out_models_oc  = os.path.join(models_dir, "ocsvm", date_path)
    out_models_db  = os.path.join(models_dir, "dbscan", date_path)
    out_results    = os.path.join(results_dir, "dbscan", date_path)
    ensure_dirs(out_models_d2v, out_models_oc, out_models_db, out_results)
    df = load_dynamodb_json_folder(input_dir)
    if df.empty:
        df = load_parquet_folder_local(input_dir)
    if df.empty:
        raise RuntimeError("No input data found (DynamoDB JSON or Parquet) in input directory")
    time_col = _pick_col(df, EVT_TIME, ["eventtime","event_time"])
    name_col = _pick_col(df, EVT_NAME, ["eventname","event_name"])
    if time_col is None or name_col is None:
        raise RuntimeError(f"Cannot find eventTime/eventName columns in df: {list(df.columns)[:20]} ...")
    df = df[[time_col, name_col]].rename(columns={time_col:"eventTime", name_col:"eventName"})
    df["eventTime"] = pd.to_datetime(df["eventTime"], errors="coerce")
    df = df.dropna(subset=["eventTime","eventName"]).sort_values("eventTime")
    tokens_all = df["eventName"].astype(str).tolist()
    if len(tokens_all) < WIN:
        raise RuntimeError(f"Not enough events ({len(tokens_all)}) for window size {WIN}")
    corpus_train = sliding_windows(tokens_all, win=WIN, stride=STRIDE1)
    if not corpus_train:
        raise RuntimeError("No training sequences for Doc2Vec")
    log.info(f"Training Doc2Vec: vector_size={VEC}, window={WIN}, docs={len(corpus_train)}")
    d2v = train_doc2vec(corpus_train, vec_size=VEC, window=WIN, epochs=30)
    import os as _os
    d2v.save(_os.path.join(out_models_d2v, "model.bin"))
    ts = df["eventTime"].values
    bps = breakpoints_by_gap(ts, gap_minutes=GAP)
    seqs_seg = sequences_by_segments(tokens_all, bps, win=WIN_SEG, stride=STRIDE5, max_per_seg=MAX_PER)
    X_oc = np.array(infer_batch(d2v, seqs_seg, epochs=30)) if seqs_seg else np.empty((0, VEC))
    from sklearn.preprocessing import StandardScaler
    if len(X_oc) > 0:
        scaler = StandardScaler(with_mean=True, with_std=True).fit(X_oc)
        Xs = scaler.transform(X_oc)
        oc = train_ocsvm(Xs, nu=OCSVM_NU)
        import joblib
        joblib.dump({"scaler": scaler, "model": oc}, os.path.join(out_models_oc, "model.joblib"))
    X_db = np.array(infer_batch(d2v, corpus_train, epochs=30))
    eps, labels, db = run_dbscan_cosine(X_db, min_samples=DB_MIN, k=DB_K, pctl=DB_P)
     # ★★★ DBSCAN 아티팩트 저장 (components/core_labels/params.json) ★★
    import json as _json
    # 코어 샘플과 라벨
    components = db.components_                       # (n_core, VEC)
    core_idx   = db.core_sample_indices_              # indices into X_db
    core_labels = db.labels_[core_idx]                # 코어 샘플의 클러스터 라벨

    # npy 저장
    np.save(os.path.join(out_models_db, "components.npy"), components)
    np.save(os.path.join(out_models_db, "core_labels.npy"), core_labels)

    # params.json 저장 (실시간 추론에서 필요)
    params = {
        "metric": "cosine",
        "eps": float(db.eps),
        "min_samples": int(db.min_samples),
        "k_neighbors": int(DB_K),
        "eps_percentile": int(DB_P),
    }
    with open(os.path.join(out_models_db, "params.json"), "w", encoding="utf-8") as f:
        _json.dump(params, f)
    stats = {
        "date": date_path,
        "count_events": int(len(df)),
        "count_seqs_train": int(len(corpus_train)),
        "count_seqs_seg": int(len(seqs_seg)),
        "dbscan_eps": float(eps),
        "dbscan_clusters": int(len(set([l for l in labels if l != -1]))),
        "dbscan_noise_ratio": float(sum([1 for l in labels if l == -1]) / len(labels)) if len(labels) > 0 else 0.0,
        "columns_used": {"eventTime": "eventTime", "eventName": "eventName"}
    }
    save_json(os.path.join(out_results, "stats.json"), stats)
    with open(os.path.join(out_results, "labels.csv"), "w", encoding="utf-8") as f:
        f.write("idx,label\n")
        for i, l in enumerate(labels):
            f.write(f"{i},{l}\n")
    log.info("All done.")
    return 0
if __name__ == "__main__":
    sys.exit(main())
